package com.atguigu.daijia.mgr.service;

public interface CustomerInfoService {

}
