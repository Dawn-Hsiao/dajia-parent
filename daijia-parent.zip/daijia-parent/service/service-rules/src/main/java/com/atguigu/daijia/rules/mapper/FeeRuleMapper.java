package com.atguigu.daijia.rules.mapper;

import com.atguigu.daijia.model.entity.rule.FeeRule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FeeRuleMapper extends BaseMapper<FeeRule> {


}
